package com.dm7blog.elektrikhesap

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat


class MainActivity : AppCompatActivity() {
    private lateinit var guc: EditText
    private lateinit var sure: EditText
    private lateinit var birimfiyat: EditText
    private lateinit var harcama: TextView
    private lateinit var surum: TextView
    private lateinit var bthesapla: Button
    private lateinit var bttemizle: Button
    private lateinit var sprefs: SharedPreferences
    private lateinit var editor: SharedPreferences.Editor
    private lateinit var spguc: Spinner
    private lateinit var spsure: Spinner
    private lateinit var dataAdapterForGuc: ArrayAdapter<String>
    private lateinit var dataAdapterForSure: ArrayAdapter<String>
    private lateinit var s:String

    //Spinner içerisine koyacağımız verileri tanımlıyoruz.
    private val gucbirimleri = arrayOf("KWatt", "Watt")
    private val sureler = arrayOf("Saat", "Dakika", "Saniye")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        guc = findViewById(R.id.etGuc);
        sure = findViewById(R.id.etSure);
        birimfiyat = findViewById(R.id.etBirimFiyat);
        harcama = findViewById(R.id.tvHarcama);

        surum = findViewById(R.id.tvSurum)
        surum.text= "Sürüm : 1.0.20042025"

        spguc = findViewById(R.id.spGuc)
        dataAdapterForGuc = ArrayAdapter(this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item, gucbirimleri)
        dataAdapterForGuc.setDropDownViewResource(R.layout.spinner_list)
        spguc.adapter = dataAdapterForGuc

        spsure = findViewById(R.id.spSure)
        dataAdapterForSure = ArrayAdapter(this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item, sureler)
        dataAdapterForSure.setDropDownViewResource(R.layout.spinner_list)
        spsure.setAdapter(dataAdapterForSure)

        sprefs = getSharedPreferences("my_shared_pref", Context.MODE_PRIVATE)
        editor = sprefs.edit()
        ayarlarioku()

        bthesapla = findViewById(R.id.btHesapla)
        bthesapla.setOnClickListener {
            hesapla()
            ayarlarisakla()
        }

        bttemizle = findViewById(R.id.btTemizle)
        bttemizle.setOnClickListener {
            guc.setText("0")
            sure.setText("0")
            birimfiyat.setText("0")
            harcama.text = "Harcama : 0 Kwh & 0 ₺"
            ayarlarisil()
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    private fun Index_Al(spinner: Spinner, myString: String?): Int {
        var index = 0

        for (i in 0..<spinner.count) {
            if (spinner.getItemAtPosition(i).toString().equals(myString, ignoreCase = true)) {
                index = i
                break
            }
        }
        return index
    }

    private fun ayarlarioku() {
        //vkm.setText(String.format("%.2f",sprefs.getFloat("VarisKm", 0)));
        guc.setText(sprefs.getString("Guc", "0"))
        sure.setText(sprefs.getString("Sure", "0"))
        birimfiyat.setText(sprefs.getString("BirimFiyat", "0"))
        harcama.setText(sprefs.getString("Harcama", "Harcama : 0 Kwh & 0 ₺"))

        s = sprefs.getString("GucBirimi", "KWatt").toString()
        spguc.setSelection(Index_Al(spguc, s))
        s = sprefs.getString("SureBirimi", "Saat").toString()
        spsure.setSelection(Index_Al(spsure, s))
    }

    private fun ayarlarisakla() {
        // Ayarlar kaydediliyor
        editor.putString("Guc", guc.text.toString())
        editor.putString("Sure", sure.text.toString())
        editor.putString("BirimFiyat", birimfiyat.text.toString())
        editor.putString("Harcama", harcama.text.toString())
        editor.putString("GucBirimi", spguc.selectedItem.toString())
        editor.putString("SureBirimi", spsure.selectedItem.toString())
        editor.apply()
    }

    private fun ayarlarisil() {
        // Ayarlar siliniyor
        editor.remove("Guc")
        editor.remove("Sure")
        editor.remove("BirimFiyat")
        editor.remove("Harcama")
        editor.remove("GucBirimi")
        editor.remove("SureBirimi")
        editor.clear()
        editor.apply()
    }

    fun hesapla() {
        var hguc: Float
        var hsure: Float
        val hsonuc: Float

        hguc = guc.text.toString().toFloat()
        hsure = sure.text.toString().toFloat()
        val hbirimfiyat = birimfiyat.text.toString().toFloat()

        if (spguc.selectedItem.toString().contentEquals("Watt")) {
            hguc = hguc / 1000
        }

        if (spsure.selectedItem.toString().contentEquals("Saniye")) {
            hsure = hsure / 3600
        }

        if (spsure.selectedItem.toString().contentEquals("Dakika")) {
            hsure = hsure / 60
        }

        val hkwh = hguc * hsure
        hsonuc = hkwh * hbirimfiyat
        harcama.text = "Harcama : " + String.format("%.2f", hkwh) + " Kwh & " + String.format("%.2f",hsonuc) + " ₺"
    }
}